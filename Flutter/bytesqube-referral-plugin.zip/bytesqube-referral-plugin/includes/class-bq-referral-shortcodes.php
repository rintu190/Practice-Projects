<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BQ_Referral_Shortcodes {

	public function __construct() {
		add_shortcode( 'bytesqube_referral_dashboard', array( $this, 'render_dashboard' ) );
		add_action( 'init', array( $this, 'handle_payout_request' ) );
		add_action( 'init', array( $this, 'handle_blog_submission' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function enqueue_assets() {
		// Only enqueue on pages with the shortcode generally, but for simplicity here we register and let WP handle dependencies if needed.
		// Optimized: Check for shortcode presence could be done, but we'll queue it.
		// using time() to bust cache
		wp_enqueue_style( 'bqr-style', BQR_PLUGIN_URL . 'assets/css/bqr-style.css', array(), time() );
		wp_enqueue_script( 'bqr-script', BQR_PLUGIN_URL . 'assets/js/bqr-script.js', array(), BQR_VERSION, true );
	}

	public function render_dashboard( $atts ) {
		if ( ! is_user_logged_in() ) {
			return '<div class="bqr-alert">Please <a href="' . wp_login_url( get_permalink() ) . '" style="margin-left:5px; font-weight:700;">login</a> to view your Affiliate Dashboard.</div>';
		}

		$user_id = get_current_user_id();
		$tracker = new BQ_Referral_Tracker();
		$wallet = new BQ_Referral_Wallet();

		// Data
		$referral_link = $tracker::get_referral_link( $user_id );
		$balance = $wallet->get_balance( $user_id );
		
		global $wpdb;
		// 1. Clicks (Unchanged)
		$clicks = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bqr_clicks WHERE affiliate_id = %d", $user_id ) );
		
		// 2. Referrals (Exclude blog posts)
		$referrals = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d AND status = 'verified' AND type != 'blog_post'", $user_id ) );
		
		// 3. Earnings (Sales Commissions only)
		$earnings = $wpdb->get_var( $wpdb->prepare( "SELECT SUM(amount) FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d AND status = 'verified' AND type != 'blog_post'", $user_id ) );
		
		// 4. Blog Earnings
		$blog_earnings = $wpdb->get_var( $wpdb->prepare( "SELECT SUM(amount) FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d AND status = 'verified' AND type = 'blog_post'", $user_id ) );
		
		// Social Share Links
		$share_text = urlencode( "Check out this amazing site! " );
		$share_url = urlencode( $referral_link );
		
		$wa_link = "https://wa.me/?text={$share_text}{$share_url}";
		$fb_link = "https://www.facebook.com/sharer/sharer.php?u={$share_url}";
		$tw_link = "https://twitter.com/intent/tweet?text={$share_text}&url={$share_url}";
		$li_link = "https://www.linkedin.com/sharing/share-offsite/?url={$share_url}";
		
		// QR Code
		$qr_api = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . $share_url;

		ob_start();
		?>
		<div class="bqr-dashboard">
			
			<?php if ( isset( $_GET['bqr_msg'] ) ) : ?>
				<div class="bqr-success"><?php echo esc_html( $_GET['bqr_msg'] ); ?></div>
			<?php endif; ?>

			<div class="bqr-stats-grid">
				<div class="bqr-card">
					<h3>Total Clicks</h3>
					<div class="value"><?php echo number_format( $clicks ); ?></div>
				</div>
				<div class="bqr-card">
					<h3>Referrals</h3>
					<div class="value"><?php echo number_format( $referrals ); ?></div>
				</div>
				<div class="bqr-card">
					<h3>Referral Earnings</h3>
					<div class="value"><?php echo wc_price( $earnings ? $earnings : 0 ); ?></div>
				</div>
				<div class="bqr-card" style="background: #f0fdf4; border-color: #bbf7d0;">
					<h3>Blog Earnings</h3>
					<div class="value" style="color: #15803d;"><?php echo wc_price( $blog_earnings ? $blog_earnings : 0 ); ?></div>
				</div>
				<div class="bqr-card highlight">
					<h3>Wallet Balance</h3>
					<div class="value"><?php echo wc_price( $balance ); ?></div>
				</div>
			</div>

			<div class="bqr-section">
				<h2>
					Your Referral Link
					<span style="font-size:0.8rem; font-weight:400; color:#6b7280;">Share & Earn</span>
				</h2>
				
				<div class="bqr-share-cointainer">
					<div class="bqr-share-actions">
						<p style="margin-top:0; color:#4b5563;">Share your unique link with friends or on social media.</p>
						
						<div class="bqr-input-group">
							<input type="text" id="bqr-ref-link" value="<?php echo esc_url( $referral_link ); ?>" readonly>
							<button class="bqr-btn bqr-btn-primary" id="bqr-copy-btn">
								Copy Link
							</button>
						</div>
						
						<div style="margin-top: 24px;">
							<p style="font-size:0.875rem; font-weight:500; margin-bottom:12px;">Share directly:</p>
							<div style="display: flex; gap: 10px; flex-wrap:wrap;">
								<a href="<?php echo $wa_link; ?>" target="_blank" class="bqr-btn bqr-btn-social btn-whatsapp bqr-share-btn">WhatsApp</a>
								<a href="<?php echo $fb_link; ?>" target="_blank" class="bqr-btn bqr-btn-social btn-facebook bqr-share-btn">Facebook</a>
								<a href="<?php echo $tw_link; ?>" target="_blank" class="bqr-btn bqr-btn-social btn-twitter bqr-share-btn">Twitter</a>
								<a href="<?php echo $li_link; ?>" target="_blank" class="bqr-btn bqr-btn-social btn-linkedin bqr-share-btn">LinkedIn</a>
							</div>
						</div>
					</div>

					<div class="bqr-qr-code">
						<img src="<?php echo esc_url( $qr_api ); ?>" alt="QR Code" width="150" height="150">
						<span>Scan to visit</span>
					</div>
				</div>
			<div class="bqr-section">
				<h2 style="border-bottom: 2px solid #f0f0f0;">Performance Analytics</h2>
				
				<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 24px;">
					<!-- Top Pages -->
					<div>
						<h3 style="margin-bottom: 16px; font-size: 1.1rem; color: #111;">Top Visited Pages</h3>
						<div class="table-responsive">
							<table class="bqr-table">
								<thead>
									<tr>
										<th>Page URL</th>
										<th>Visits</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$top_pages = $wpdb->get_results( $wpdb->prepare( 
										"SELECT page_visited, COUNT(*) as visits FROM {$wpdb->prefix}bqr_clicks WHERE affiliate_id = %d GROUP BY page_visited ORDER BY visits DESC LIMIT 5", 
										$user_id 
									) );
									
									if ( $top_pages ) : foreach ( $top_pages as $page ) : ?>
										<tr>
											<td style="word-break: break-all;"><a href="<?php echo esc_url( home_url( $page->page_visited ) ); ?>" target="_blank"><?php echo esc_html( $page->page_visited ); ?></a></td>
											<td style="font-weight:700;"><?php echo number_format( $page->visits ); ?></td>
										</tr>
									<?php endforeach; else: ?>
										<tr><td colspan="2" style="color:#999;">No visits recorded yet.</td></tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>

					<!-- Commission Status Breakdown -->
					<div>
						<h3 style="margin-bottom: 16px; font-size: 1.1rem; color: #111;">Commission Status</h3>
						<?php
						$stats = $wpdb->get_results( $wpdb->prepare( 
							"SELECT status, COUNT(*) as count, SUM(amount) as total FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d AND type != 'blog_post' GROUP BY status", 
							$user_id 
						) );
						
						$stats_map = array();
						if($stats) {
							foreach($stats as $s) $stats_map[$s->status] = $s;
						}
						
						$statuses = ['verified', 'pending', 'rejected'];
						?>
						<div style="display:flex; flex-direction:column; gap:12px;">
							<?php foreach($statuses as $st): 
								$data = isset($stats_map[$st]) ? $stats_map[$st] : (object)['count'=>0, 'total'=>0];
								$label = ucfirst($st);
								$color = ($st == 'verified') ? '#10B981' : (($st == 'pending') ? '#F59E0B' : '#EF4444');
								$bg = ($st == 'verified') ? '#ECFDF5' : (($st == 'pending') ? '#FFFBEB' : '#FEF2F2');
							?>
							<div style="background: <?php echo $bg; ?>; padding: 15px; border-radius: 8px; border: 1px solid <?php echo $color; ?>30; display:flex; justify-content:space-between; align-items:center;">
								<div>
									<span style="display:block; font-size:0.8rem; font-weight:600; color:<?php echo $color; ?>; text-transform:uppercase;"><?php echo $label; ?> Sales</span>
									<span style="font-size:1.2rem; font-weight:700; color:#333;"><?php echo number_format($data->count); ?></span>
								</div>
								<div style="text-align:right;">
									<span style="display:block; font-size:0.8rem; color:#666;">Earnings</span>
									<span style="font-size:1.1rem; font-weight:700; color:#333;"><?php echo wc_price($data->total); ?></span>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>

				<!-- Recent Conversions -->
				<div style="margin-top: 40px;">
					<h3 style="margin-bottom: 16px; font-size: 1.1rem; color: #111;">Recent Conversions (Orders)</h3>
					<div class="table-responsive">
						<table class="bqr-table">
							<thead>
								<tr>
									<th>Date</th>
									<th>Order ID</th>
									<th>Order Total</th>
									<th>Commission</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$recent_refs = $wpdb->get_results( $wpdb->prepare( 
									"SELECT * FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d ORDER BY created_at DESC LIMIT 10", 
									$user_id 
								) );
								
								if ( $recent_refs ) : foreach ( $recent_refs as $ref ) : 
									$order = wc_get_order( $ref->reference_id );
									$order_total = $order ? $order->get_total() : 'N/A';
								?>
									<tr>
										<td><?php echo date_i18n( get_option( 'date_format' ), strtotime( $ref->created_at ) ); ?></td>
										<td>#<?php echo esc_html( $ref->reference_id ); ?></td>
										<td><?php echo is_numeric($order_total) ? wc_price($order_total) : $order_total; ?></td>
										<td><?php echo wc_price( $ref->amount ); ?></td>
										<td><span class="status-badge status-<?php echo esc_attr( $ref->status ); ?>"><?php echo ucfirst( $ref->status ); ?></span></td>
									</tr>
								<?php endforeach; else: ?>
									<tr><td colspan="5" style="text-align:center; padding: 20px; color: #999;">No conversions generated yet.</td></tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>

			<!-- Blog Posting Section -->
			<div class="bqr-section">
				<h2 style="border-bottom: 2px solid #f0f0f0;">Blog Posting Program</h2>
				<p style="color:#666;">Earn an extra <strong><?php echo wc_price( get_option('bqr_blog_bounty', 100) ); ?></strong> for every blog post you write about us!</p>
				
				<form method="post" style="margin-top: 20px; background: #f9fafb; padding: 20px; border-radius: 8px;">
					<?php wp_nonce_field( 'bqr_submit_blog', 'bqr_blog_nonce' ); ?>
					<h3 style="margin-top:0; font-size:1rem;">Submit Your Post</h3>
					<div class="bqr-input-group" style="max-width: 100%;">
						<input type="url" name="bqr_blog_url" placeholder="Enter your blog post URL (e.g., https://myblog.com/review)" required style="background:white;">
						<button type="submit" name="bqr_action" value="submit_blog" class="bqr-btn bqr-btn-primary">Submit for Review</button>
					</div>
				</form>

				<h3 style="margin-top: 30px; font-size: 1.1rem;">Submission History</h3>
				<div class="table-responsive">
					<table class="bqr-table">
						<thead>
							<tr>
								<th>Date</th>
								<th>URL</th>
								<th>Status</th>
								<th>Bounty</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$blogs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bqr_referrals WHERE affiliate_id = %d AND type = 'blog_post' ORDER BY created_at DESC LIMIT 5", $user_id ) );
							if ( $blogs ) :
								foreach ( $blogs as $blog ) : ?>
								<tr>
									<td><?php echo date_i18n( get_option( 'date_format' ), strtotime( $blog->created_at ) ); ?></td>
									<td style="word-break: break-all;"><a href="<?php echo esc_url( $blog->description ); ?>" target="_blank" style="color:#2563eb; text-decoration:none;">View Post</a></td>
									<td><span class="status-badge status-<?php echo esc_attr( $blog->status ); ?>"><?php echo ucfirst( $blog->status ); ?></span></td>
									<td><?php echo wc_price( $blog->amount ); ?></td>
								</tr>
							<?php endforeach; else: ?>
								<tr><td colspan="4" style="text-align:center; padding: 24px; color: #9ca3af;">No blog posts submitted yet.</td></tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>

			<div class="bqr-section">
				<div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e5e7eb; padding-bottom: 16px; margin-bottom: 24px;">
					<h2 style="border:none; margin:0; padding:0;">Payout Requests</h2>
					
					<form method="post" style="display: inline-flex; gap: 10px; align-items: center;">
						<?php wp_nonce_field( 'bqr_request_payout', 'bqr_nonce' ); ?>
						<select name="bqr_payout_method" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px; background:white;" <?php disabled( $balance < 50 ); ?>>
							<option value="bank">Bank Transfer</option>
							<option value="paypal">PayPal</option>
							<option value="upi">UPI</option>
						</select>
						<?php if ( $balance >= 50 ) : ?>
							<button type="submit" name="bqr_action" value="request_payout" class="bqr-btn bqr-btn-primary">Request Payout</button>
						<?php else: ?>
							<button type="button" class="bqr-btn" style="background: #e5e7eb; color:#9ca3af; cursor: not-allowed;" title="Minimum balance of 50 required">Min Balance 50</button>
						<?php endif; ?>
					</form>
				</div>

				<div class="table-responsive">
					<table class="bqr-table">
						<thead>
							<tr>
								<th>Date</th>
								<th>Amount</th>
								<th>Method</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$payouts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bqr_payouts WHERE affiliate_id = %d ORDER BY created_at DESC LIMIT 5", $user_id ) );
							if ( $payouts ) :
								foreach ( $payouts as $payout ) : ?>
								<tr>
									<td><?php echo date_i18n( get_option( 'date_format' ), strtotime( $payout->created_at ) ); ?></td>
									<td><?php echo wc_price( $payout->amount ); ?></td>
									<td><?php echo ucfirst( $payout->method ); ?></td>
									<td><span class="status-badge status-<?php echo esc_attr( $payout->status ); ?>"><?php echo ucfirst( $payout->status ); ?></span></td>
								</tr>
							<?php endforeach; else: ?>
								<tr><td colspan="4" style="text-align:center; padding: 24px; color: #9ca3af;">No payout history found.</td></tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public function handle_payout_request() {
		if ( isset( $_POST['bqr_action'] ) && $_POST['bqr_action'] == 'request_payout' ) {
			if ( ! is_user_logged_in() ) return;
			if ( ! wp_verify_nonce( $_POST['bqr_nonce'], 'bqr_request_payout' ) ) return;

			$user_id = get_current_user_id();
			$wallet = new BQ_Referral_Wallet();
			$balance = $wallet->get_balance( $user_id );

			if ( $balance >= 50 ) {
				global $wpdb;
				$method = isset($_POST['bqr_payout_method']) ? sanitize_text_field($_POST['bqr_payout_method']) : 'manual';
				
				// 1. Create Payout Request
				$wpdb->insert(
					$wpdb->prefix . 'bqr_payouts',
					array(
						'affiliate_id' => $user_id,
						'amount'       => $balance, 
						'method'       => $method,
						'details'      => 'User requested payout via ' . ucfirst($method),
						'status'       => 'pending'
					),
					array( '%d', '%f', '%s', '%s', '%s' )
				);
				
				$payout_id = $wpdb->insert_id;
				
				// Notify Admin
				do_action( 'bqr_payout_requested', $payout_id, $user_id );

				// 2. Debit Wallet immediately
				$wallet->add_transaction( $user_id, -$balance, 'payout', $payout_id, 'Payout Request #' . $payout_id );

				wp_redirect( add_query_arg( 'bqr_msg', 'Payout requested successfully!', remove_query_arg( 'bqr_action' ) ) );
				exit;
			}
		}
	}
	public function handle_blog_submission() {
		if ( isset( $_POST['bqr_action'] ) && $_POST['bqr_action'] == 'submit_blog' ) {
			if ( ! is_user_logged_in() ) return;
			if ( ! wp_verify_nonce( $_POST['bqr_blog_nonce'], 'bqr_submit_blog' ) ) return;

			$url = esc_url_raw( $_POST['bqr_blog_url'] );
			if ( empty( $url ) ) return;

			$user_id = get_current_user_id();
			global $wpdb;
			
			// Duplicate check
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}bqr_referrals WHERE description = %s AND type='blog_post'", $url ) );
			if ( $exists ) {
				wp_redirect( add_query_arg( 'bqr_msg', 'This URL has already been submitted.', remove_query_arg( 'bqr_action' ) ) );
				exit;
			}

			$amount = get_option( 'bqr_blog_bounty', 100 );
			
			$wpdb->insert(
				$wpdb->prefix . 'bqr_referrals',
				array(
					'affiliate_id' => $user_id,
					'reference_id' => 'blog_' . time() . '_' . rand(100,999),
					'type'         => 'blog_post',
					'amount'       => $amount,
					'currency'     => get_woocommerce_currency(),
					'status'       => 'pending',
					'description'  => $url
				),
				array( '%d', '%s', '%s', '%f', '%s', '%s', '%s' )
			);

			wp_redirect( add_query_arg( 'bqr_msg', 'Blog post submitted successfully for review!', remove_query_arg( 'bqr_action' ) ) );
			exit;
		}
	}
}
new BQ_Referral_Shortcodes();
